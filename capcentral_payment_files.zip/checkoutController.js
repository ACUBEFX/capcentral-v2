
const paystackService = require('../services/paystackService');
const db = require('../models/database');
const {
    sendProductPaymentConfirmationEmail
} = require('../utils/mailer');

// Mark only Caps as sold, once per verified Paystack reference. Other categories
// retain their existing stock behaviour. A DB transaction prevents duplicate
// callbacks/webhooks from decrementing the same cap twice.
async function markPurchasedCapsSold(reference, cart) {
    if (!reference || !Array.isArray(cart)) {
        throw new Error('Missing payment reference or valid cart metadata.');
    }

    const capItems = cart.filter(item =>
        item && (item.productId || item.product_id || item.id ||
                 item.productCode || item.product_code || item.name)
    );
    if (!capItems.length) return;

    const connection = await db.promise().getConnection();
    try {
        await connection.beginTransaction();

        const [alreadyProcessed] = await connection.query(
            'SELECT reference FROM processed_cap_payments WHERE reference = ? FOR UPDATE',
            [reference]
        );
        if (alreadyProcessed.length) {
            await connection.commit();
            return;
        }

        for (const item of capItems) {
            const id = Number(item.productId || item.product_id || item.id);
            const code = item.productCode || item.product_code;
            let rows;
            if (Number.isInteger(id) && id > 0) {
                [rows] = await connection.query(
                    'SELECT id, category, stock_quantity FROM products WHERE id = ? FOR UPDATE', [id]
                );
            } else if (code) {
                [rows] = await connection.query(
                    'SELECT id, category, stock_quantity FROM products WHERE product_code = ? FOR UPDATE', [String(code)]
                );
            } else if (item.name) {
                // Backward compatibility for carts saved before product IDs/codes were added.
                [rows] = await connection.query(
                    `SELECT id, category, stock_quantity FROM products
                     WHERE name = ? AND category = 'Caps' LIMIT 1 FOR UPDATE`, [String(item.name)]
                );
            } else {
                continue;
            }

            // Ignore non-cap products: their stock must not be changed by this cap-specific logic.
            if (!rows.length || String(rows[0].category).toLowerCase() !== 'caps') continue;

            const quantity = Math.max(1, Number(item.quantity) || 1);
            if (Number(rows[0].stock_quantity) < quantity) {
                throw new Error(`Cap ${id || code} is already sold or has insufficient stock.`);
            }
            const [updated] = await connection.query(
                `UPDATE products SET stock_quantity = stock_quantity - ?
                 WHERE id = ? AND category = 'Caps' AND stock_quantity >= ?`,
                [quantity, rows[0].id, quantity]
            );
            if (updated.affectedRows !== 1) {
                throw new Error(`Could not reserve cap ${id || code}; stock may have changed.`);
            }
        }

        await connection.query(
            'INSERT INTO processed_cap_payments (reference) VALUES (?)', [reference]
        );
        await connection.commit();
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
    }
}



// =====================================================
// RENDER CHECKOUT PAGE
// =====================================================
exports.renderCheckoutPage = (req, res) => {
    try {
        const {
            cart,
            total,
            returnUrl
        } = req.body;

        let cartParsed = [];

        try {
            cartParsed = JSON.parse(cart);
        } catch (error) {
            console.error('❌ Error parsing cart:', error);
        }

        res.render('checkout', {
            cart: cartParsed,
            total: total,
            returnUrl: returnUrl || '/products'
        });

    } catch (error) {
        console.error(
            '❌ Error rendering checkout page:',
            error
        );

        res.status(500).send(
            'Unable to load checkout page.'
        );
    }
};


// =====================================================
// INITIALIZE PAYSTACK PAYMENT
// =====================================================
exports.handlePaystackInit = async (req, res) => {
    try {
        const {
            email,
            total,
            cart,
            deliveryOption,
            expressSurcharge,
            returnUrl
        } = req.body;

        let cartParsed = [];

        try {
            cartParsed = JSON.parse(cart);
        } catch (error) {
            console.error(
                '❌ Error parsing cart:',
                error
            );

            return res
                .status(400)
                .send('Invalid cart data.');
        }

        if (!Array.isArray(cartParsed) || cartParsed.length === 0) {
            return res.status(400).send('Your cart is empty or invalid.');
        }

        // Re-check current inventory immediately before initializing payment.
        // Caps are one-off items, so a cap cannot be purchased more than once.
        const db = require('../models/database');
        const connection = await db.promise().getConnection();
        try {
            for (const item of cartParsed) {
                const id = Number(item.productId || item.product_id || item.id);
                const code = item.productCode || item.product_code;
                let rows = [];
                if (Number.isInteger(id) && id > 0) {
                    [rows] = await connection.query(
                        'SELECT id, category, stock_quantity FROM products WHERE id = ?', [id]
                    );
                } else if (code) {
                    [rows] = await connection.query(
                        'SELECT id, category, stock_quantity FROM products WHERE product_code = ?', [String(code)]
                    );
                } else if (item.name) {
                    [rows] = await connection.query(
                        `SELECT id, category, stock_quantity FROM products
                         WHERE name = ? AND category = 'Caps' LIMIT 1`, [String(item.name)]
                    );
                }
                if (rows.length && String(rows[0].category).toLowerCase() === 'caps') {
                    if (Number(rows[0].stock_quantity) < 1 || Number(item.quantity || 1) !== 1) {
                        return res.status(409).send('This cap is sold or unavailable. Remove it from your cart and refresh the Caps page.');
                    }
                }
            }
        } finally {
            connection.release();
        }

        const amount = Math.round(
            Number(total) * 100
        );

        // =================================================
        // SAFELY VALIDATE RETURN URL
        // =================================================
        let safeReturnUrl =
            returnUrl || '/products';

        if (
            typeof safeReturnUrl !== 'string' ||
            !safeReturnUrl.startsWith('/') ||
            safeReturnUrl.startsWith('//')
        ) {
            safeReturnUrl = '/products';
        }

        console.log('🛒 Cart:', cartParsed);
        console.log('🚚 Delivery:', deliveryOption);
        console.log('💰 Total:', total);
        console.log(
            '↩️ Return URL:',
            safeReturnUrl
        );

        // =================================================
        // INITIALIZE PAYSTACK
        // =================================================
        const paymentData =
            await paystackService.initializeTransaction(
                email,
                amount,
                cartParsed,
                deliveryOption || 'standard',
                Number(expressSurcharge) || 0,
                safeReturnUrl
            );

        console.log(
            '✅ Paystack payment initialized.'
        );

        res.redirect(
            paymentData.authorization_url
        );

    } catch (error) {
        console.error(
            '❌ Paystack initialization error:',
            error.response?.data ||
            error.message
        );

        res.status(500).send(
            'Unable to initialize payment.'
        );
    }
};


// =====================================================
// PAYSTACK CALLBACK AFTER PAYMENT
// =====================================================
exports.handlePaystackCallback = async (req, res) => {
    try {
        const {
            reference
        } = req.query;

        console.log(
            '🔎 Verifying Paystack payment:',
            reference
        );

        if (!reference) {
            return res.render('failure', {
                data: {
                    status: 'error',
                    reference: ''
                }
            });
        }

        // =================================================
        // VERIFY PAYMENT WITH PAYSTACK
        // =================================================
        const paymentData =
            await paystackService.verifyTransaction(
                reference
            );

        console.log(
            '💳 Paystack payment status:',
            paymentData.status
        );

        // =================================================
        // PAYMENT SUCCESS
        // =================================================
        if (
            paymentData.status === 'success'
        ) {
            console.log(
                '✅ Payment verified successfully.'
            );

            // ---------------------------------------------
            // GET PAYSTACK METADATA
            // ---------------------------------------------
            let metadata =
                paymentData.metadata || {};

            // Paystack may return metadata as JSON string
            if (
                typeof metadata === 'string'
            ) {
                try {
                    metadata =
                        JSON.parse(metadata);
                } catch (error) {
                    console.error(
                        '❌ Error parsing metadata:',
                        error
                    );

                    metadata = {};
                }
            }

            // ---------------------------------------------
            // UPDATE CAP STOCK ONLY AFTER PAYSTACK VERIFIES
            // THIS TRANSACTION AS SUCCESSFUL.
            // ---------------------------------------------
            let verifiedCart = metadata.cart || [];
            if (typeof verifiedCart === 'string') {
                try { verifiedCart = JSON.parse(verifiedCart); } catch (_) { verifiedCart = []; }
            }
            await markPurchasedCapsSold(reference, verifiedCart);

            // ---------------------------------------------
            // GET RETURN URL
            // ---------------------------------------------
            let returnUrl =
                metadata.returnUrl ||
                '/products';

            // ---------------------------------------------
            // SECURITY CHECK
            // Only allow local paths
            // ---------------------------------------------
            if (
                typeof returnUrl !== 'string' ||
                !returnUrl.startsWith('/') ||
                returnUrl.startsWith('//')
            ) {
                returnUrl = '/products';
            }

            // ---------------------------------------------
            // SHOW SESSION BEFORE SAVE
            // ---------------------------------------------
            console.log(
                '👤 Session before redirect:',
                req.session
            );

            console.log(
                '👤 Logged-in user:',
                req.session.user
            );

            console.log(
                '↩️ Returning customer to:',
                returnUrl
            );

            // =================================================
            // SAVE SESSION BEFORE REDIRECT
            // =================================================
            return req.session.save(
                (err) => {

                    if (err) {
                        console.error(
                            '❌ Error saving session:',
                            err
                        );

                        return res
                            .status(500)
                            .send(
                                'Could not preserve login session.'
                            );
                    }

                    console.log(
                        '✅ Session saved successfully.'
                    );

                    console.log(
                        '👤 User after session save:',
                        req.session.user
                    );

                    console.log(
                        '↩️ Redirecting to:',
                        returnUrl
                    );

                    // -----------------------------------------
                    // REDIRECT BACK TO ORIGINAL PAGE
                    // -----------------------------------------
                    return res.redirect(
    `${returnUrl}${returnUrl.includes('?') ? '&' : '?'}payment=success`
);
                }
            );
        }

        // =================================================
        // PAYMENT FAILED
        // =================================================
        return res.render('failure', {
            data: paymentData
        });

    } catch (error) {

        console.error(
            '❌ Paystack callback error:',
            error.response?.data ||
            error.message
        );

        return res.render('failure', {
            data: {
                status: 'error',
                reference:
                    req.query.reference || ''
            }
        });
    }
};


// =====================================================
// PAYSTACK WEBHOOK
// =====================================================
exports.handlePaystackWebhook = async (
    req,
    res
) => {
    try {

        console.log(
            '📩 Paystack webhook received:',
            req.body.event
        );

        const event = req.body;

        // =================================================
        // ONLY PROCESS SUCCESSFUL PAYMENTS
        // =================================================
        if (
            event.event !== 'charge.success'
        ) {
            return res.sendStatus(200);
        }

        const eventData = event.data || {};
        if (!eventData.reference) return res.sendStatus(200);

        // Verify the reference directly with Paystack before changing stock.
        const paymentData = await paystackService.verifyTransaction(eventData.reference);
        if (paymentData.status !== 'success') return res.sendStatus(200);

        console.log(
            '💳 Verified successful payment:',
            paymentData.reference
        );

        // =================================================
        // GET METADATA
        // =================================================
        const metadata =
            paymentData.metadata || {};

        // =================================================
        // CUSTOMER INFORMATION
        // =================================================
        const customerEmail =
            paymentData.customer?.email ||
            metadata.email ||
            '';

        const customerName =
            metadata.name ||
            paymentData.customer?.first_name ||
            'Customer';

        // =================================================
        // GET CART
        // =================================================
        let cart =
            metadata.cart || [];

        // Paystack may return cart as JSON string
        if (
            typeof cart === 'string'
        ) {
            try {
                cart =
                    JSON.parse(cart);
            } catch (error) {

                console.error(
                    '❌ Error parsing webhook cart:',
                    error
                );

                cart = [];
            }
        }

        await markPurchasedCapsSold(paymentData.reference, cart);

        // =================================================
        // DELIVERY OPTION
        // =================================================
        let deliveryOption =
            metadata.deliveryOption ||
            'standard';

        // Paystack may return an array
        if (
            Array.isArray(
                deliveryOption
            )
        ) {
            deliveryOption =
                deliveryOption[0] ||
                'standard';
        }

        deliveryOption =
            String(
                deliveryOption
            ).toLowerCase();

        // =================================================
        // EXPRESS SURCHARGE
        // =================================================
        const expressSurcharge =
            Number(
                metadata.expressSurcharge
            ) || 0;

        // =================================================
        // TOTAL AMOUNT
        // Paystack amount is in kobo
        // =================================================
        const totalAmount =
            Number(
                paymentData.amount
            ) / 100;

        console.log(
            '👤 Customer:',
            customerEmail
        );

        console.log(
            '📦 Cart:',
            cart
        );

        console.log(
            '🚚 Delivery:',
            deliveryOption
        );

        console.log(
            '💰 Total:',
            totalAmount
        );

        // =================================================
        // SEND CAPCENTRAL ORDER CONFIRMATION EMAIL
        // =================================================
        await sendProductPaymentConfirmationEmail(
            {
                name: customerName,
                email: customerEmail
            },
            cart,
            totalAmount,
            deliveryOption,
            expressSurcharge,
            paymentData.reference
        );

        console.log(
            '✅ CapCentral order confirmation email sent.'
        );

        return res.sendStatus(200);

    } catch (error) {

        console.error(
            '❌ Paystack webhook error:',
            error.message
        );

        return res.sendStatus(500);
    }
};
